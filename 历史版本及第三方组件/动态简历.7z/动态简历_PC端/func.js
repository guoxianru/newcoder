!function (e) {
    function t(r) {
        if (n[r]) return n[r].exports;
        var i = n[r] = {i: r, l: !1, exports: {}};
        return e[r].call(i.exports, i, i.exports, t), i.l = !0, i.exports
    }

    var n = {};
    t.m = e, t.c = n, t.d = function (e, n, r) {
        t.o(e, n) || Object.defineProperty(e, n, {configurable: !1, enumerable: !0, get: r})
    }, t.n = function (e) {
        var n = e && e.__esModule ? function () {
            return e.default
        } : function () {
            return e
        };
        return t.d(n, "a", n), n
    }, t.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, t.p = "", t(t.s = 13)
}({
    0: function (e, t) {
        var n;
        n = function () {
            return this
        }();
        try {
            n = n || Function("return this")() || (0, eval)("this")
        } catch (e) {
            "object" == typeof window && (n = window)
        }
        e.exports = n
    }, 1: function (e, t, n) {
        (function (t) {
            var n = "undefined" != typeof window ? window : "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? self : {},
                r = function () {
                    var e = /\blang(?:uage)?-(\w+)\b/i, t = 0, r = n.Prism = {
                        util: {
                            encode: function (e) {
                                return e instanceof i ? new i(e.type, r.util.encode(e.content), e.alias) : "Array" === r.util.type(e) ? e.map(r.util.encode) : e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ")
                            }, type: function (e) {
                                return Object.prototype.toString.call(e).match(/\[object (\w+)\]/)[1]
                            }, objId: function (e) {
                                return e.__id || Object.defineProperty(e, "__id", {value: ++t}), e.__id
                            }, clone: function (e) {
                                switch (r.util.type(e)) {
                                    case"Object":
                                        var t = {};
                                        for (var n in e) e.hasOwnProperty(n) && (t[n] = r.util.clone(e[n]));
                                        return t;
                                    case"Array":
                                        return e.map && e.map(function (e) {
                                            return r.util.clone(e)
                                        })
                                }
                                return e
                            }
                        }, languages: {
                            extend: function (e, t) {
                                var n = r.util.clone(r.languages[e]);
                                for (var i in t) n[i] = t[i];
                                return n
                            }, insertBefore: function (e, t, n, i) {
                                i = i || r.languages;
                                var s = i[e];
                                if (2 == arguments.length) {
                                    n = arguments[1];
                                    for (var a in n) n.hasOwnProperty(a) && (s[a] = n[a]);
                                    return s
                                }
                                var l = {};
                                for (var o in s) if (s.hasOwnProperty(o)) {
                                    if (o == t) for (var a in n) n.hasOwnProperty(a) && (l[a] = n[a]);
                                    l[o] = s[o]
                                }
                                return r.languages.DFS(r.languages, function (t, n) {
                                    n === i[e] && t != e && (this[t] = l)
                                }), i[e] = l
                            }, DFS: function (e, t, n, i) {
                                i = i || {};
                                for (var s in e) e.hasOwnProperty(s) && (t.call(e, s, e[s], n || s), "Object" !== r.util.type(e[s]) || i[r.util.objId(e[s])] ? "Array" !== r.util.type(e[s]) || i[r.util.objId(e[s])] || (i[r.util.objId(e[s])] = !0, r.languages.DFS(e[s], t, s, i)) : (i[r.util.objId(e[s])] = !0, r.languages.DFS(e[s], t, null, i)))
                            }
                        }, plugins: {}, highlightAll: function (e, t) {
                            var n = {
                                callback: t,
                                selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
                            };
                            r.hooks.run("before-highlightall", n);
                            for (var i, s = n.elements || document.querySelectorAll(n.selector), a = 0; i = s[a++];) r.highlightElement(i, !0 === e, n.callback)
                        }, highlightElement: function (t, i, s) {
                            for (var a, l, o = t; o && !e.test(o.className);) o = o.parentNode;
                            o && (a = (o.className.match(e) || [, ""])[1].toLowerCase(), l = r.languages[a]), t.className = t.className.replace(e, "").replace(/\s+/g, " ") + " language-" + a, o = t.parentNode, /pre/i.test(o.nodeName) && (o.className = o.className.replace(e, "").replace(/\s+/g, " ") + " language-" + a);
                            var u = t.textContent, h = {element: t, language: a, grammar: l, code: u};
                            if (r.hooks.run("before-sanity-check", h), !h.code || !h.grammar) return h.code && (h.element.textContent = h.code), void r.hooks.run("complete", h);
                            if (r.hooks.run("before-highlight", h), i && n.Worker) {
                                var p = new Worker(r.filename);
                                p.onmessage = function (e) {
                                    h.highlightedCode = e.data, r.hooks.run("before-insert", h), h.element.innerHTML = h.highlightedCode, s && s.call(h.element), r.hooks.run("after-highlight", h), r.hooks.run("complete", h)
                                }, p.postMessage(JSON.stringify({
                                    language: h.language,
                                    code: h.code,
                                    immediateClose: !0
                                }))
                            } else h.highlightedCode = r.highlight(h.code, h.grammar, h.language), r.hooks.run("before-insert", h), h.element.innerHTML = h.highlightedCode, s && s.call(t), r.hooks.run("after-highlight", h), r.hooks.run("complete", h)
                        }, highlight: function (e, t, n) {
                            var s = r.tokenize(e, t);
                            return i.stringify(r.util.encode(s), n)
                        }, tokenize: function (e, t, n) {
                            var i = r.Token, s = [e], a = t.rest;
                            if (a) {
                                for (var l in a) t[l] = a[l];
                                delete t.rest
                            }
                            e:for (var l in t) if (t.hasOwnProperty(l) && t[l]) {
                                var o = t[l];
                                o = "Array" === r.util.type(o) ? o : [o];
                                for (var u = 0; u < o.length; ++u) {
                                    var h = o[u], p = h.inside, c = !!h.lookbehind, g = !!h.greedy, d = 0, f = h.alias;
                                    if (g && !h.pattern.global) {
                                        var m = h.pattern.toString().match(/[imuy]*$/)[0];
                                        h.pattern = RegExp(h.pattern.source, m + "g")
                                    }
                                    h = h.pattern || h;
                                    for (var b = 0, k = 0; b < s.length; k += s[b].length, ++b) {
                                        var y = s[b];
                                        if (s.length > e.length) break e;
                                        if (!(y instanceof i)) {
                                            h.lastIndex = 0;
                                            var x = h.exec(y), w = 1;
                                            if (!x && g && b != s.length - 1) {
                                                if (h.lastIndex = k, !(x = h.exec(e))) break;
                                                for (var v = x.index + (c ? x[1].length : 0), _ = x.index + x[0].length, S = b, $ = k, A = s.length; S < A && $ < _; ++S) $ += s[S].length, v >= $ && (++b, k = $);
                                                if (s[b] instanceof i || s[S - 1].greedy) continue;
                                                w = S - b, y = e.slice(k, $), x.index -= k
                                            }
                                            if (x) {
                                                c && (d = x[1].length);
                                                var v = x.index + d, x = x[0].slice(d), _ = v + x.length,
                                                    L = y.slice(0, v), j = y.slice(_), C = [b, w];
                                                L && C.push(L);
                                                var q = new i(l, p ? r.tokenize(x, p) : x, f, x, g);
                                                C.push(q), j && C.push(j), Array.prototype.splice.apply(s, C)
                                            }
                                        }
                                    }
                                }
                            }
                            return s
                        }, hooks: {
                            all: {}, add: function (e, t) {
                                var n = r.hooks.all;
                                n[e] = n[e] || [], n[e].push(t)
                            }, run: function (e, t) {
                                var n = r.hooks.all[e];
                                if (n && n.length) for (var i, s = 0; i = n[s++];) i(t)
                            }
                        }
                    }, i = r.Token = function (e, t, n, r, i) {
                        this.type = e, this.content = t, this.alias = n, this.length = 0 | (r || "").length, this.greedy = !!i
                    };
                    if (i.stringify = function (e, t, n) {
                        if ("string" == typeof e) return e;
                        if ("Array" === r.util.type(e)) return e.map(function (n) {
                            return i.stringify(n, t, e)
                        }).join("");
                        var s = {
                            type: e.type,
                            content: i.stringify(e.content, t, n),
                            tag: "span",
                            classes: ["token", e.type],
                            attributes: {},
                            language: t,
                            parent: n
                        };
                        if ("comment" == s.type && (s.attributes.spellcheck = "true"), e.alias) {
                            var a = "Array" === r.util.type(e.alias) ? e.alias : [e.alias];
                            Array.prototype.push.apply(s.classes, a)
                        }
                        r.hooks.run("wrap", s);
                        var l = Object.keys(s.attributes).map(function (e) {
                            return e + '="' + (s.attributes[e] || "").replace(/"/g, "&quot;") + '"'
                        }).join(" ");
                        return "<" + s.tag + ' class="' + s.classes.join(" ") + '"' + (l ? " " + l : "") + ">" + s.content + "</" + s.tag + ">"
                    }, !n.document) return n.addEventListener ? (n.addEventListener("message", function (e) {
                        var t = JSON.parse(e.data), i = t.language, s = t.code, a = t.immediateClose;
                        n.postMessage(r.highlight(s, r.languages[i], i)), a && n.close()
                    }, !1), n.Prism) : n.Prism;
                    var s = document.currentScript || [].slice.call(document.getElementsByTagName("script")).pop();
                    return s && (r.filename = s.src, document.addEventListener && !s.hasAttribute("data-manual") && ("loading" !== document.readyState ? window.requestAnimationFrame ? window.requestAnimationFrame(r.highlightAll) : window.setTimeout(r.highlightAll, 16) : document.addEventListener("DOMContentLoaded", r.highlightAll))), n.Prism
                }();
            void 0 !== e && e.exports && (e.exports = r), void 0 !== t && (t.Prism = r), r.languages.markup = {
                comment: /<!--[\w\W]*?-->/,
                prolog: /<\?[\w\W]+?\?>/,
                doctype: /<!DOCTYPE[\w\W]+?>/i,
                cdata: /<!\[CDATA\[[\w\W]*?]]>/i,
                tag: {
                    pattern: /<\/?(?!\d)[^\s>\/=$<]+(?:\s+[^\s>\/=]+(?:=(?:("|')(?:\\\1|\\?(?!\1)[\w\W])*\1|[^\s'">=]+))?)*\s*\/?>/i,
                    inside: {
                        tag: {
                            pattern: /^<\/?[^\s>\/]+/i,
                            inside: {punctuation: /^<\/?/, namespace: /^[^\s>\/:]+:/}
                        },
                        "attr-value": {pattern: /=(?:('|")[\w\W]*?(\1)|[^\s>]+)/i, inside: {punctuation: /[=>"']/}},
                        punctuation: /\/?>/,
                        "attr-name": {pattern: /[^\s>\/]+/, inside: {namespace: /^[^\s>\/:]+:/}}
                    }
                },
                entity: /&#?[\da-z]{1,8};/i
            }, r.hooks.add("wrap", function (e) {
                "entity" === e.type && (e.attributes.title = e.content.replace(/&amp;/, "&"))
            }), r.languages.xml = r.languages.markup, r.languages.html = r.languages.markup, r.languages.mathml = r.languages.markup, r.languages.svg = r.languages.markup, r.languages.css = {
                comment: /\/\*[\w\W]*?\*\//,
                atrule: {pattern: /@[\w-]+?.*?(;|(?=\s*\{))/i, inside: {rule: /@[\w-]+/}},
                url: /url\((?:(["'])(\\(?:\r\n|[\w\W])|(?!\1)[^\\\r\n])*\1|.*?)\)/i,
                selector: /[^\{\}\s][^\{\};]*?(?=\s*\{)/,
                string: {pattern: /("|')(\\(?:\r\n|[\w\W])|(?!\1)[^\\\r\n])*\1/, greedy: !0},
                property: /(\b|\B)[\w-]+(?=\s*:)/i,
                important: /\B!important\b/i,
                function: /[-a-z0-9]+(?=\()/i,
                punctuation: /[(){};:]/
            }, r.languages.css.atrule.inside.rest = r.util.clone(r.languages.css), r.languages.markup && (r.languages.insertBefore("markup", "tag", {
                style: {
                    pattern: /(<style[\w\W]*?>)[\w\W]*?(?=<\/style>)/i,
                    lookbehind: !0,
                    inside: r.languages.css,
                    alias: "language-css"
                }
            }), r.languages.insertBefore("inside", "attr-value", {
                "style-attr": {
                    pattern: /\s*style=("|').*?\1/i,
                    inside: {
                        "attr-name": {pattern: /^\s*style/i, inside: r.languages.markup.tag.inside},
                        punctuation: /^\s*=\s*['"]|['"]\s*$/,
                        "attr-value": {pattern: /.+/i, inside: r.languages.css}
                    },
                    alias: "language-css"
                }
            }, r.languages.markup.tag)), r.languages.clike = {
                comment: [{
                    pattern: /(^|[^\\])\/\*[\w\W]*?\*\//,
                    lookbehind: !0
                }, {pattern: /(^|[^\\:])\/\/.*/, lookbehind: !0}],
                string: {pattern: /(["'])(\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/, greedy: !0},
                "class-name": {
                    pattern: /((?:\b(?:class|interface|extends|implements|trait|instanceof|new)\s+)|(?:catch\s+\())[a-z0-9_\.\\]+/i,
                    lookbehind: !0,
                    inside: {punctuation: /(\.|\\)/}
                },
                keyword: /\b(if|else|while|do|for|return|in|instanceof|function|new|try|throw|catch|finally|null|break|continue)\b/,
                boolean: /\b(true|false)\b/,
                function: /[a-z0-9_]+(?=\()/i,
                number: /\b-?(?:0x[\da-f]+|\d*\.?\d+(?:e[+-]?\d+)?)\b/i,
                operator: /--?|\+\+?|!=?=?|<=?|>=?|==?=?|&&?|\|\|?|\?|\*|\/|~|\^|%/,
                punctuation: /[{}[\];(),.:]/
            }, r.languages.javascript = r.languages.extend("clike", {
                keyword: /\b(as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|var|void|while|with|yield)\b/,
                number: /\b-?(0x[\dA-Fa-f]+|0b[01]+|0o[0-7]+|\d*\.?\d+([Ee][+-]?\d+)?|NaN|Infinity)\b/,
                function: /[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*(?=\()/i,
                operator: /--?|\+\+?|!=?=?|<=?|>=?|==?=?|&&?|\|\|?|\?|\*\*?|\/|~|\^|%|\.{3}/
            }), r.languages.insertBefore("javascript", "keyword", {
                regex: {
                    pattern: /(^|[^\/])\/(?!\/)(\[.+?]|\\.|[^\/\\\r\n])+\/[gimyu]{0,5}(?=\s*($|[\r\n,.;})]))/,
                    lookbehind: !0,
                    greedy: !0
                }
            }), r.languages.insertBefore("javascript", "string", {
                "template-string": {
                    pattern: /`(?:\\\\|\\?[^\\])*?`/,
                    greedy: !0,
                    inside: {
                        interpolation: {
                            pattern: /\$\{[^}]+\}/,
                            inside: {
                                "interpolation-punctuation": {pattern: /^\$\{|\}$/, alias: "punctuation"},
                                rest: r.languages.javascript
                            }
                        }, string: /[\s\S]+/
                    }
                }
            }), r.languages.markup && r.languages.insertBefore("markup", "tag", {
                script: {
                    pattern: /(<script[\w\W]*?>)[\w\W]*?(?=<\/script>)/i,
                    lookbehind: !0,
                    inside: r.languages.javascript,
                    alias: "language-javascript"
                }
            }), r.languages.js = r.languages.javascript, function () {
                "undefined" != typeof self && self.Prism && self.document && document.querySelector && (self.Prism.fileHighlight = function () {
                    var e = {
                        js: "javascript",
                        py: "python",
                        rb: "ruby",
                        ps1: "powershell",
                        psm1: "powershell",
                        sh: "bash",
                        bat: "batch",
                        h: "c",
                        tex: "latex"
                    };
                    Array.prototype.forEach && Array.prototype.slice.call(document.querySelectorAll("pre[data-src]")).forEach(function (t) {
                        for (var n, i = t.getAttribute("data-src"), s = t, a = /\blang(?:uage)?-(?!\*)(\w+)\b/i; s && !a.test(s.className);) s = s.parentNode;
                        if (s && (n = (t.className.match(a) || [, ""])[1]), !n) {
                            var l = (i.match(/\.(\w+)$/) || [, ""])[1];
                            n = e[l] || l
                        }
                        var o = document.createElement("code");
                        o.className = "language-" + n, t.textContent = "", o.textContent = "Loading…", t.appendChild(o);
                        var u = new XMLHttpRequest;
                        u.open("GET", i, !0), u.onreadystatechange = function () {
                            4 == u.readyState && (u.status < 400 && u.responseText ? (o.textContent = u.responseText, r.highlightElement(o)) : u.status >= 400 ? o.textContent = "✖ Error " + u.status + " while fetching file: " + u.statusText : o.textContent = "✖ Error: File does not exist or is empty")
                        }, u.send(null)
                    })
                }, document.addEventListener("DOMContentLoaded", self.Prism.fileHighlight))
            }()
        }).call(t, n(0))
    }, 13: function (e, t, n) {
        n(2), e.exports = n(1)
    }, 2: function (e, t, n) {
        (function (t) {
            (function () {
                function t(e) {
                    this.tokens = [], this.tokens.links = {}, this.options = e || h.defaults, this.rules = p.normal, this.options.gfm && (this.options.tables ? this.rules = p.tables : this.rules = p.gfm)
                }

                function n(e, t) {
                    if (this.options = t || h.defaults, this.links = e, this.rules = c.normal, this.renderer = this.options.renderer || new r, this.renderer.options = this.options, !this.links) throw new Error("Tokens array requires a `links` property.");
                    this.options.gfm ? this.options.breaks ? this.rules = c.breaks : this.rules = c.gfm : this.options.pedantic && (this.rules = c.pedantic)
                }

                function r(e) {
                    this.options = e || {}
                }

                function i(e) {
                    this.tokens = [], this.token = null, this.options = e || h.defaults, this.options.renderer = this.options.renderer || new r, this.renderer = this.options.renderer, this.renderer.options = this.options
                }

                function s(e, t) {
                    return e.replace(t ? /&/g : /&(?!#?\w+;)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;")
                }

                function a(e) {
                    return e.replace(/&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/g, function (e, t) {
                        return t = t.toLowerCase(), "colon" === t ? ":" : "#" === t.charAt(0) ? "x" === t.charAt(1) ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""
                    })
                }

                function l(e, t) {
                    return e = e.source, t = t || "", function n(r, i) {
                        return r ? (i = i.source || i, i = i.replace(/(^|[^\[])\^/g, "$1"), e = e.replace(r, i), n) : new RegExp(e, t)
                    }
                }

                function o() {
                }

                function u(e) {
                    for (var t, n, r = 1; r < arguments.length; r++) {
                        t = arguments[r];
                        for (n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    }
                    return e
                }

                function h(e, n, r) {
                    if (r || "function" == typeof n) {
                        r || (r = n, n = null), n = u({}, h.defaults, n || {});
                        var a, l, o = n.highlight, p = 0;
                        try {
                            a = t.lex(e, n)
                        } catch (e) {
                            return r(e)
                        }
                        l = a.length;
                        var c = function (e) {
                            if (e) return n.highlight = o, r(e);
                            var t;
                            try {
                                t = i.parse(a, n)
                            } catch (t) {
                                e = t
                            }
                            return n.highlight = o, e ? r(e) : r(null, t)
                        };
                        if (!o || o.length < 3) return c();
                        if (delete n.highlight, !l) return c();
                        for (; p < a.length; p++) !function (e) {
                            "code" !== e.type ? --l || c() : o(e.text, e.lang, function (t, n) {
                                return t ? c(t) : null == n || n === e.text ? --l || c() : (e.text = n, e.escaped = !0, void (--l || c()))
                            })
                        }(a[p])
                    } else try {
                        return n && (n = u({}, h.defaults, n)), i.parse(t.lex(e, n), n)
                    } catch (e) {
                        if (e.message += "\nPlease report this to https://github.com/chjj/marked.", (n || h.defaults).silent) return "<p>An error occured:</p><pre>" + s(e.message + "", !0) + "</pre>";
                        throw e
                    }
                }

                var p = {
                    newline: /^\n+/,
                    code: /^( {4}[^\n]+\n*)+/,
                    fences: o,
                    hr: /^( *[-*_]){3,} *(?:\n+|$)/,
                    heading: /^ *(#{1,6}) *([^\n]+?) *#* *(?:\n+|$)/,
                    nptable: o,
                    lheading: /^([^\n]+)\n *(=|-){2,} *(?:\n+|$)/,
                    blockquote: /^( *>[^\n]+(\n(?!def)[^\n]+)*\n*)+/,
                    list: /^( *)(bull) [\s\S]+?(?:hr|def|\n{2,}(?! )(?!\1bull )\n*|\s*$)/,
                    html: /^ *(?:comment *(?:\n|\s*$)|closed *(?:\n{2,}|\s*$)|closing *(?:\n{2,}|\s*$))/,
                    def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +["(]([^\n]+)[")])? *(?:\n+|$)/,
                    table: o,
                    paragraph: /^((?:[^\n]+\n?(?!hr|heading|lheading|blockquote|tag|def))+)\n*/,
                    text: /^[^\n]+/
                };
                p.bullet = /(?:[*+-]|\d+\.)/, p.item = /^( *)(bull) [^\n]*(?:\n(?!\1bull )[^\n]*)*/, p.item = l(p.item, "gm")(/bull/g, p.bullet)(), p.list = l(p.list)(/bull/g, p.bullet)("hr", "\\n+(?=\\1?(?:[-*_] *){3,}(?:\\n+|$))")("def", "\\n+(?=" + p.def.source + ")")(), p.blockquote = l(p.blockquote)("def", p.def)(), p._tag = "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:/|[^\\w\\s@]*@)\\b", p.html = l(p.html)("comment", /<!--[\s\S]*?-->/)("closed", /<(tag)[\s\S]+?<\/\1>/)("closing", /<tag(?:"[^"]*"|'[^']*'|[^'">])*?>/)(/tag/g, p._tag)(), p.paragraph = l(p.paragraph)("hr", p.hr)("heading", p.heading)("lheading", p.lheading)("blockquote", p.blockquote)("tag", "<" + p._tag)("def", p.def)(), p.normal = u({}, p), p.gfm = u({}, p.normal, {
                    fences: /^ *(`{3,}|~{3,})[ \.]*(\S+)? *\n([\s\S]*?)\s*\1 *(?:\n+|$)/,
                    paragraph: /^/,
                    heading: /^ *(#{1,6}) +([^\n]+?) *#* *(?:\n+|$)/
                }), p.gfm.paragraph = l(p.paragraph)("(?!", "(?!" + p.gfm.fences.source.replace("\\1", "\\2") + "|" + p.list.source.replace("\\1", "\\3") + "|")(), p.tables = u({}, p.gfm, {
                    nptable: /^ *(\S.*\|.*)\n *([-:]+ *\|[-| :]*)\n((?:.*\|.*(?:\n|$))*)\n*/,
                    table: /^ *\|(.+)\n *\|( *[-:]+[-| :]*)\n((?: *\|.*(?:\n|$))*)\n*/
                }), t.rules = p, t.lex = function (e, n) {
                    return new t(n).lex(e)
                }, t.prototype.lex = function (e) {
                    return e = e.replace(/\r\n|\r/g, "\n").replace(/\t/g, "    ").replace(/\u00a0/g, " ").replace(/\u2424/g, "\n"), this.token(e, !0)
                }, t.prototype.token = function (e, t, n) {
                    for (var r, i, s, a, l, o, u, h, c, e = e.replace(/^ +$/gm, ""); e;) if ((s = this.rules.newline.exec(e)) && (e = e.substring(s[0].length), s[0].length > 1 && this.tokens.push({type: "space"})), s = this.rules.code.exec(e)) e = e.substring(s[0].length), s = s[0].replace(/^ {4}/gm, ""), this.tokens.push({
                        type: "code",
                        text: this.options.pedantic ? s : s.replace(/\n+$/, "")
                    }); else if (s = this.rules.fences.exec(e)) e = e.substring(s[0].length), this.tokens.push({
                        type: "code",
                        lang: s[2],
                        text: s[3] || ""
                    }); else if (s = this.rules.heading.exec(e)) e = e.substring(s[0].length), this.tokens.push({
                        type: "heading",
                        depth: s[1].length,
                        text: s[2]
                    }); else if (t && (s = this.rules.nptable.exec(e))) {
                        for (e = e.substring(s[0].length), o = {
                            type: "table",
                            header: s[1].replace(/^ *| *\| *$/g, "").split(/ *\| */),
                            align: s[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
                            cells: s[3].replace(/\n$/, "").split("\n")
                        }, h = 0; h < o.align.length; h++) /^ *-+: *$/.test(o.align[h]) ? o.align[h] = "right" : /^ *:-+: *$/.test(o.align[h]) ? o.align[h] = "center" : /^ *:-+ *$/.test(o.align[h]) ? o.align[h] = "left" : o.align[h] = null;
                        for (h = 0; h < o.cells.length; h++) o.cells[h] = o.cells[h].split(/ *\| */);
                        this.tokens.push(o)
                    } else if (s = this.rules.lheading.exec(e)) e = e.substring(s[0].length), this.tokens.push({
                        type: "heading",
                        depth: "=" === s[2] ? 1 : 2,
                        text: s[1]
                    }); else if (s = this.rules.hr.exec(e)) e = e.substring(s[0].length), this.tokens.push({type: "hr"}); else if (s = this.rules.blockquote.exec(e)) e = e.substring(s[0].length), this.tokens.push({type: "blockquote_start"}), s = s[0].replace(/^ *> ?/gm, ""), this.token(s, t, !0), this.tokens.push({type: "blockquote_end"}); else if (s = this.rules.list.exec(e)) {
                        for (e = e.substring(s[0].length), a = s[2], this.tokens.push({
                            type: "list_start",
                            ordered: a.length > 1
                        }), s = s[0].match(this.rules.item), r = !1, c = s.length, h = 0; h < c; h++) o = s[h], u = o.length, o = o.replace(/^ *([*+-]|\d+\.) +/, ""), ~o.indexOf("\n ") && (u -= o.length, o = this.options.pedantic ? o.replace(/^ {1,4}/gm, "") : o.replace(new RegExp("^ {1," + u + "}", "gm"), "")), this.options.smartLists && h !== c - 1 && (l = p.bullet.exec(s[h + 1])[0], a === l || a.length > 1 && l.length > 1 || (e = s.slice(h + 1).join("\n") + e, h = c - 1)), i = r || /\n\n(?!\s*$)/.test(o), h !== c - 1 && (r = "\n" === o.charAt(o.length - 1), i || (i = r)), this.tokens.push({type: i ? "loose_item_start" : "list_item_start"}), this.token(o, !1, n), this.tokens.push({type: "list_item_end"});
                        this.tokens.push({type: "list_end"})
                    } else if (s = this.rules.html.exec(e)) e = e.substring(s[0].length), this.tokens.push({
                        type: this.options.sanitize ? "paragraph" : "html",
                        pre: !this.options.sanitizer && ("pre" === s[1] || "script" === s[1] || "style" === s[1]),
                        text: s[0]
                    }); else if (!n && t && (s = this.rules.def.exec(e))) e = e.substring(s[0].length), this.tokens.links[s[1].toLowerCase()] = {
                        href: s[2],
                        title: s[3]
                    }; else if (t && (s = this.rules.table.exec(e))) {
                        for (e = e.substring(s[0].length), o = {
                            type: "table",
                            header: s[1].replace(/^ *| *\| *$/g, "").split(/ *\| */),
                            align: s[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
                            cells: s[3].replace(/(?: *\| *)?\n$/, "").split("\n")
                        }, h = 0; h < o.align.length; h++) /^ *-+: *$/.test(o.align[h]) ? o.align[h] = "right" : /^ *:-+: *$/.test(o.align[h]) ? o.align[h] = "center" : /^ *:-+ *$/.test(o.align[h]) ? o.align[h] = "left" : o.align[h] = null;
                        for (h = 0; h < o.cells.length; h++) o.cells[h] = o.cells[h].replace(/^ *\| *| *\| *$/g, "").split(/ *\| */);
                        this.tokens.push(o)
                    } else if (t && (s = this.rules.paragraph.exec(e))) e = e.substring(s[0].length), this.tokens.push({
                        type: "paragraph",
                        text: "\n" === s[1].charAt(s[1].length - 1) ? s[1].slice(0, -1) : s[1]
                    }); else if (s = this.rules.text.exec(e)) e = e.substring(s[0].length), this.tokens.push({
                        type: "text",
                        text: s[0]
                    }); else if (e) throw new Error("Infinite loop on byte: " + e.charCodeAt(0));
                    return this.tokens
                };
                var c = {
                    escape: /^\\([\\`*{}\[\]()#+\-.!_>])/,
                    autolink: /^<([^ >]+(@|:\/)[^ >]+)>/,
                    url: o,
                    tag: /^<!--[\s\S]*?-->|^<\/?\w+(?:"[^"]*"|'[^']*'|[^'">])*?>/,
                    link: /^!?\[(inside)\]\(href\)/,
                    reflink: /^!?\[(inside)\]\s*\[([^\]]*)\]/,
                    nolink: /^!?\[((?:\[[^\]]*\]|[^\[\]])*)\]/,
                    strong: /^__([\s\S]+?)__(?!_)|^\*\*([\s\S]+?)\*\*(?!\*)/,
                    em: /^\b_((?:[^_]|__)+?)_\b|^\*((?:\*\*|[\s\S])+?)\*(?!\*)/,
                    code: /^(`+)\s*([\s\S]*?[^`])\s*\1(?!`)/,
                    br: /^ {2,}\n(?!\s*$)/,
                    del: o,
                    text: /^[\s\S]+?(?=[\\<!\[_*`]| {2,}\n|$)/
                };
                c._inside = /(?:\[[^\]]*\]|[^\[\]]|\](?=[^\[]*\]))*/, c._href = /\s*<?([\s\S]*?)>?(?:\s+['"]([\s\S]*?)['"])?\s*/, c.link = l(c.link)("inside", c._inside)("href", c._href)(), c.reflink = l(c.reflink)("inside", c._inside)(), c.normal = u({}, c), c.pedantic = u({}, c.normal, {
                    strong: /^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,
                    em: /^_(?=\S)([\s\S]*?\S)_(?!_)|^\*(?=\S)([\s\S]*?\S)\*(?!\*)/
                }), c.gfm = u({}, c.normal, {
                    escape: l(c.escape)("])", "~|])")(),
                    url: /^(https?:\/\/[^\s<]+[^<.,:;"')\]\s])/,
                    del: /^~~(?=\S)([\s\S]*?\S)~~/,
                    text: l(c.text)("]|", "~]|")("|", "|https?://|")()
                }), c.breaks = u({}, c.gfm, {
                    br: l(c.br)("{2,}", "*")(),
                    text: l(c.gfm.text)("{2,}", "*")()
                }), n.rules = c, n.output = function (e, t, r) {
                    return new n(t, r).output(e)
                }, n.prototype.output = function (e) {
                    for (var t, n, r, i, a = ""; e;) if (i = this.rules.escape.exec(e)) e = e.substring(i[0].length), a += i[1]; else if (i = this.rules.autolink.exec(e)) e = e.substring(i[0].length), "@" === i[2] ? (n = ":" === i[1].charAt(6) ? this.mangle(i[1].substring(7)) : this.mangle(i[1]), r = this.mangle("mailto:") + n) : (n = s(i[1]), r = n), a += this.renderer.link(r, null, n); else if (this.inLink || !(i = this.rules.url.exec(e))) {
                        if (i = this.rules.tag.exec(e)) !this.inLink && /^<a /i.test(i[0]) ? this.inLink = !0 : this.inLink && /^<\/a>/i.test(i[0]) && (this.inLink = !1), e = e.substring(i[0].length), a += this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(i[0]) : s(i[0]) : i[0]; else if (i = this.rules.link.exec(e)) e = e.substring(i[0].length), this.inLink = !0, a += this.outputLink(i, {
                            href: i[2],
                            title: i[3]
                        }), this.inLink = !1; else if ((i = this.rules.reflink.exec(e)) || (i = this.rules.nolink.exec(e))) {
                            if (e = e.substring(i[0].length), t = (i[2] || i[1]).replace(/\s+/g, " "), !(t = this.links[t.toLowerCase()]) || !t.href) {
                                a += i[0].charAt(0), e = i[0].substring(1) + e;
                                continue
                            }
                            this.inLink = !0, a += this.outputLink(i, t), this.inLink = !1
                        } else if (i = this.rules.strong.exec(e)) e = e.substring(i[0].length), a += this.renderer.strong(this.output(i[2] || i[1])); else if (i = this.rules.em.exec(e)) e = e.substring(i[0].length), a += this.renderer.em(this.output(i[2] || i[1])); else if (i = this.rules.code.exec(e)) e = e.substring(i[0].length), a += this.renderer.codespan(s(i[2], !0)); else if (i = this.rules.br.exec(e)) e = e.substring(i[0].length), a += this.renderer.br(); else if (i = this.rules.del.exec(e)) e = e.substring(i[0].length), a += this.renderer.del(this.output(i[1])); else if (i = this.rules.text.exec(e)) e = e.substring(i[0].length), a += this.renderer.text(s(this.smartypants(i[0]))); else if (e) throw new Error("Infinite loop on byte: " + e.charCodeAt(0))
                    } else e = e.substring(i[0].length), n = s(i[1]), r = n, a += this.renderer.link(r, null, n);
                    return a
                }, n.prototype.outputLink = function (e, t) {
                    var n = s(t.href), r = t.title ? s(t.title) : null;
                    return "!" !== e[0].charAt(0) ? this.renderer.link(n, r, this.output(e[1])) : this.renderer.image(n, r, s(e[1]))
                }, n.prototype.smartypants = function (e) {
                    return this.options.smartypants ? e.replace(/---/g, "—").replace(/--/g, "–").replace(/(^|[-\u2014\/(\[{"\s])'/g, "$1‘").replace(/'/g, "’").replace(/(^|[-\u2014\/(\[{\u2018\s])"/g, "$1“").replace(/"/g, "”").replace(/\.{3}/g, "…") : e
                }, n.prototype.mangle = function (e) {
                    if (!this.options.mangle) return e;
                    for (var t, n = "", r = e.length, i = 0; i < r; i++) t = e.charCodeAt(i), Math.random() > .5 && (t = "x" + t.toString(16)), n += "&#" + t + ";";
                    return n
                }, r.prototype.code = function (e, t, n) {
                    if (this.options.highlight) {
                        var r = this.options.highlight(e, t);
                        null != r && r !== e && (n = !0, e = r)
                    }
                    return t ? '<pre><code class="' + this.options.langPrefix + s(t, !0) + '">' + (n ? e : s(e, !0)) + "\n</code></pre>\n" : "<pre><code>" + (n ? e : s(e, !0)) + "\n</code></pre>"
                }, r.prototype.blockquote = function (e) {
                    return "<blockquote>\n" + e + "</blockquote>\n"
                }, r.prototype.html = function (e) {
                    return e
                }, r.prototype.heading = function (e, t, n) {
                    return "<h" + t + ' id="' + this.options.headerPrefix + n.toLowerCase().replace(/[^\w]+/g, "-") + '">' + e + "</h" + t + ">\n"
                }, r.prototype.hr = function () {
                    return this.options.xhtml ? "<hr/>\n" : "<hr>\n"
                }, r.prototype.list = function (e, t) {
                    var n = t ? "ol" : "ul";
                    return "<" + n + ">\n" + e + "</" + n + ">\n"
                }, r.prototype.listitem = function (e) {
                    return "<li>" + e + "</li>\n"
                }, r.prototype.paragraph = function (e) {
                    return "<p>" + e + "</p>\n"
                }, r.prototype.table = function (e, t) {
                    return "<table>\n<thead>\n" + e + "</thead>\n<tbody>\n" + t + "</tbody>\n</table>\n"
                }, r.prototype.tablerow = function (e) {
                    return "<tr>\n" + e + "</tr>\n"
                }, r.prototype.tablecell = function (e, t) {
                    var n = t.header ? "th" : "td";
                    return (t.align ? "<" + n + ' style="text-align:' + t.align + '">' : "<" + n + ">") + e + "</" + n + ">\n"
                }, r.prototype.strong = function (e) {
                    return "<strong>" + e + "</strong>"
                }, r.prototype.em = function (e) {
                    return "<em>" + e + "</em>"
                }, r.prototype.codespan = function (e) {
                    return "<code>" + e + "</code>"
                }, r.prototype.br = function () {
                    return this.options.xhtml ? "<br/>" : "<br>"
                }, r.prototype.del = function (e) {
                    return "<del>" + e + "</del>"
                }, r.prototype.link = function (e, t, n) {
                    if (this.options.sanitize) {
                        try {
                            var r = decodeURIComponent(a(e)).replace(/[^\w:]/g, "").toLowerCase()
                        } catch (e) {
                            return ""
                        }
                        if (0 === r.indexOf("javascript:") || 0 === r.indexOf("vbscript:")) return ""
                    }
                    var i = '<a href="' + e + '"';
                    return t && (i += ' title="' + t + '"'), i += ">" + n + "</a>"
                }, r.prototype.image = function (e, t, n) {
                    var r = '<img src="' + e + '" alt="' + n + '"';
                    return t && (r += ' title="' + t + '"'), r += this.options.xhtml ? "/>" : ">"
                }, r.prototype.text = function (e) {
                    return e
                }, i.parse = function (e, t, n) {
                    return new i(t, n).parse(e)
                }, i.prototype.parse = function (e) {
                    this.inline = new n(e.links, this.options, this.renderer), this.tokens = e.reverse();
                    for (var t = ""; this.next();) t += this.tok();
                    return t
                }, i.prototype.next = function () {
                    return this.token = this.tokens.pop()
                }, i.prototype.peek = function () {
                    return this.tokens[this.tokens.length - 1] || 0
                }, i.prototype.parseText = function () {
                    for (var e = this.token.text; "text" === this.peek().type;) e += "\n" + this.next().text;
                    return this.inline.output(e)
                }, i.prototype.tok = function () {
                    switch (this.token.type) {
                        case"space":
                            return "";
                        case"hr":
                            return this.renderer.hr();
                        case"heading":
                            return this.renderer.heading(this.inline.output(this.token.text), this.token.depth, this.token.text);
                        case"code":
                            return this.renderer.code(this.token.text, this.token.lang, this.token.escaped);
                        case"table":
                            var e, t, n, r, i = "", s = "";
                            for (n = "", e = 0; e < this.token.header.length; e++) ({
                                header: !0,
                                align: this.token.align[e]
                            }), n += this.renderer.tablecell(this.inline.output(this.token.header[e]), {
                                header: !0,
                                align: this.token.align[e]
                            });
                            for (i += this.renderer.tablerow(n), e = 0; e < this.token.cells.length; e++) {
                                for (t = this.token.cells[e], n = "", r = 0; r < t.length; r++) n += this.renderer.tablecell(this.inline.output(t[r]), {
                                    header: !1,
                                    align: this.token.align[r]
                                });
                                s += this.renderer.tablerow(n)
                            }
                            return this.renderer.table(i, s);
                        case"blockquote_start":
                            for (var s = ""; "blockquote_end" !== this.next().type;) s += this.tok();
                            return this.renderer.blockquote(s);
                        case"list_start":
                            for (var s = "", a = this.token.ordered; "list_end" !== this.next().type;) s += this.tok();
                            return this.renderer.list(s, a);
                        case"list_item_start":
                            for (var s = ""; "list_item_end" !== this.next().type;) s += "text" === this.token.type ? this.parseText() : this.tok();
                            return this.renderer.listitem(s);
                        case"loose_item_start":
                            for (var s = ""; "list_item_end" !== this.next().type;) s += this.tok();
                            return this.renderer.listitem(s);
                        case"html":
                            var l = this.token.pre || this.options.pedantic ? this.token.text : this.inline.output(this.token.text);
                            return this.renderer.html(l);
                        case"paragraph":
                            return this.renderer.paragraph(this.inline.output(this.token.text));
                        case"text":
                            return this.renderer.paragraph(this.parseText())
                    }
                }, o.exec = o, h.options = h.setOptions = function (e) {
                    return u(h.defaults, e), h
                }, h.defaults = {
                    gfm: !0,
                    tables: !0,
                    breaks: !1,
                    pedantic: !1,
                    sanitize: !1,
                    sanitizer: null,
                    mangle: !0,
                    smartLists: !1,
                    silent: !1,
                    highlight: null,
                    langPrefix: "lang-",
                    smartypants: !1,
                    headerPrefix: "",
                    renderer: new r,
                    xhtml: !1
                }, h.Parser = i, h.parser = i.parse, h.Renderer = r, h.Lexer = t, h.lexer = t.lex, h.InlineLexer = n, h.inlineLexer = n.output, h.parse = h, e.exports = h
            }).call(function () {
                return this || ("undefined" != typeof window ? window : t)
            }())
        }).call(t, n(0))
    }
});